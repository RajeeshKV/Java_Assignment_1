import java.io.*;
class Animal{
    public void shout(){
    }
}
class Dog extends Animal{
    public void shout(){
        System.out.println("Bow Bow");
    }
}
class Horse extends Animal{
    public void shout(){
        System.out.println("Mwh Mwh");
    }
}
class Cat extends Animal{
    public void shout(){
        System.out.println("Myavu Myavu");
    }
}
class Ass2{
    public static void main(String args[])throws IOException {
        Animal am = new Animal();
        System.out.println("Dog shouts: ");
        Dog d = new Dog();
        am = d;
        am.shout();
        
        System.out.println("Horse shouts: ");
        Horse h = new Horse();
        am = h;
        am.shout();
        
        System.out.println("Cat shouts: ");
        Cat c = new Cat();
        am = c;
        am.shout();
    }
}