import java.io.*;
import java.util.ArrayList;

class Employee{
    private int id;
    private String name,address;
    private float sal;
    public Employee(int tid, String tname,String taddress, float tsal){
        id = tid;
        name = tname;
        address = taddress;
        sal = tsal;
    }
    public void getDetails(){
        System.out.println("EMP ID: " + id);
        System.out.println("EMP NAME: " + name);
        System.out.println("EMP ADDRESS: " + address);
        System.out.println("EMP SALARY: " + sal);
    }
    public boolean checkEmp(int tid, String tname){
        if(tid == id && tname.equals(name)){
            return true;
        }
        else
            return false;
    }
}
class Ass7{
    public static void main(String args[])throws IOException{
    ArrayList<Employee>  arr = new ArrayList<Employee>();
    int id,lim;
    float sal;
    DataInputStream in = new DataInputStream(System.in);
    String name,address;
    
    System.out.println("Enter limit: ");
    lim = Integer.parseInt(in.readLine());
    
    for(int i=0; i<lim; i++){
        System.out.println("Enter emp id: ");
        id = Integer.parseInt(in.readLine());
        System.out.println("Enter emp name: ");
        name = in.readLine();
        System.out.println("Enter emp address: ");
        address = in.readLine();
        System.out.println("Enter emp salary: ");
        sal = Float.parseFloat(in.readLine());
        
        arr.add(new Employee(id,name,address,sal));
    }
    System.out.println("Enter emp id and name : ");
    id = Integer.parseInt(in.readLine());
    name = in.readLine();
    
    for(int i=0; i<lim; i++){
        if(arr.get(i).checkEmp(id,name)){
            arr.get(i).getDetails();
            break;
        }
        else{
            System.out.println("Employee not found");
        }
    }
    }
}