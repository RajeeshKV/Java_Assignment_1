import music.string.Veena;
import music.wind.Saxophone;
import music.Playable;
class Ass4{
    public static void main(String args[]){
        Veena v = new Veena();
        Saxophone s = new Saxophone();
        
        Playable pv,ps;
        pv = new Veena();
        ps = new Saxophone();
        
        v.play();
        s.play();
        
        pv.play();
        ps.play();
        
    }
}