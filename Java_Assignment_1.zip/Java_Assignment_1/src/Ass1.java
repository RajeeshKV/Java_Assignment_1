import java.io.*;
class Factorial {
    public int fact(int x){
        if(x==1)
            return x;
        else
            return(x*fact(x-1));
    }
}
class Ass1 {
    public static void main(String args[]) throws IOException{
        DataInputStream in = new DataInputStream(System.in);
        int num,result;
        System.out.print("Enter a digit: ");
        num = Integer.parseInt(in.readLine());
        Factorial f = new Factorial();
        result = f.fact(num);
        System.out.println(num + " factorial is " + result);
    }
}