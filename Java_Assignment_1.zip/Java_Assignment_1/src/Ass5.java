import java.io.*;
class InvalidAgeException extends Exception {
    InvalidAgeException(String s){
        super(s);
    } 
}

class ValidateAge{
    void validateAge(int age)throws InvalidAgeException {
        if(age >= 18 && age < 60){
            System.out.println("Proper age found");
        }
        else {
            throw new InvalidAgeException("Enter a proper age!!!");
        }
    }
}

class Ass5{
    public static void main(String args[])throws IOException{
        DataInputStream in = new DataInputStream(System.in);
        int age;
        String name;
        System.out.print("Enter name: ");
        name = in.readLine();
        System.out.print("Enter age: ");
        age = Integer.parseInt(in.readLine());
        ValidateAge v = new ValidateAge();
        try {
            v.validateAge(age);
        }
        catch(Exception e){
            System.out.println("Error: " + e);
        }
    }
}