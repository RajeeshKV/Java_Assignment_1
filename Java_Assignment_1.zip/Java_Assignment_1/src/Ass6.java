import java.lang.*;
import java.util.Date;

class MyThread extends Thread{
    
    String threadName;
    
    MyThread(String name){
        threadName = name;
        System.out.println("Creating thread " + threadName + "....");
    }
    
    public void run(){
        System.out.println("Thread name : " + threadName);
        try{
        Date date = new Date();
        System.out.println("Time : " + date);
        Thread.sleep(1000);
        date = new Date();
        System.out.println("Time : " + date);
        }
        catch(Exception e){
            System.out.println("Exception found " + e);
        }
    }
}
class Ass6{
    public static void main(String args[]){
        MyThread mt = new MyThread("MyThread");
        mt.start();
    }
}