abstract class Instrument{
    abstract void play();
}
class Piano extends Instrument{
    void play(){
        System.out.println("Piano is playing  tan tan tan tan");
    }
}
class Flute extends Instrument{
    void play(){
        System.out.println("Flute is playing  toot toot toot toot");
    }
}
class Guitar extends Instrument{
    void play(){
        System.out.println("Guitar is playing  tin  tin  tin ");
    }
}
class Ass3{
    public static void main(String agrs[]){
        Instrument in;
        in = new Piano();
        in.play();
        
        in = new Flute();
        in.play();
        
        in = new Guitar();
        in.play();
    }
}